from flask import Flask, render_template, request
import requests

app = Flask(__name__)

# URL của backend API
BACKEND_URL = "http://127.0.0.1:8000/calculate_salary"

@app.route('/')
def homepage():
    return render_template('index.html')

@app.route('/calculate', methods=['POST'])
def calculate_salary():
    gross_salary = float(request.form['gross_salary'])
    dependents = int(request.form['dependents'])

    # Gửi request đến backend để tính toán lương net
    data = {
        "gross_salary": gross_salary,
        "dependents": dependents
    }
    
    try:
        response = requests.post(BACKEND_URL, json=data)
        result = response.json()
        
        # Trả về kết quả tính toán cho người dùng
        return render_template('result.html', result=result)
    except requests.exceptions.RequestException as e:
        return f"Error connecting to backend: {e}"

if __name__ == '__main__':
    app.run(debug=True)
