from .constants import ConstantsSalary, TaxConfig
import pandas as pd
from io import BytesIO
from fastapi import UploadFile


def calculate_net_salary(gross_salary: float, number_of_dependents: int) -> dict:
    """Tính lương net từ lương gross và số người phụ thuộc"""
    
    # Bảo hiểm xã hội, y tế, thất nghiệp
    insurance = 0
    if gross_salary >= 36000000:
        insurance = 2880000  # Nếu lương >= 36 triệu, BHXH mặc định 2.880.000
    else:
        insurance += gross_salary * ConstantsSalary.BHXH_RATE

    if gross_salary >= 36000000:
        insurance += 540000  # Nếu lương >= 36 triệu, BHYT mặc định 540.000
    else:
        insurance += gross_salary * ConstantsSalary.BHYT_RATE

    if gross_salary >= 93600000:
        insurance += 936000  # Nếu lương >= 93.6 triệu, BHTN mặc định 936.000
    else:
        insurance += gross_salary * ConstantsSalary.BHTN_RATE

    # Tính thu nhập chịu thuế (pre-tax income)
    pre_tax_income = gross_salary - insurance - (ConstantsSalary.BASIC_DEDUCTION + number_of_dependents * ConstantsSalary.DEPENDENT_DEDUCTION)

    # Kiểm tra nếu thu nhập chịu thuế nhỏ hơn 0, thì thuế sẽ là 0
    if pre_tax_income < 0:
        personal_income_tax = 0
    else:
        personal_income_tax = 0
        for bracket in TaxConfig.BRACKETS:  # Duyệt qua từng bậc thuế
            if pre_tax_income > bracket.limit:
                personal_income_tax += (pre_tax_income - bracket.limit) * bracket.rate  # Tính thuế cho phần thu nhập vượt quá limit của bậc thuế
                pre_tax_income = bracket.limit  # Giảm thu nhập chịu thuế xuống mức của bậc thuế này

    # Tính lương net
    net_salary = gross_salary - insurance - personal_income_tax

    return {"gross_salary": gross_salary, "net_salary": net_salary, "insurance": insurance, "tax": personal_income_tax}


async def handle_upload_excel(file: UploadFile) -> BytesIO:
    """Xử lý tệp Excel và tính toán lương cho tất cả nhân viên"""
    content = await file.read()
    df = pd.read_excel(BytesIO(content))

    # Xử lý và tính toán lương cho từng nhân viên
    results = []
    for index, row in df.iterrows():
        gross_salary = row['Gross Salary']
        dependents = row['Dependents']
        result = calculate_net_salary(gross_salary, dependents)
        results.append(result)

    # Tạo file Excel mới với kết quả
    result_df = pd.DataFrame(results)
    result_file = BytesIO()
    result_df.to_excel(result_file, index=False)
    result_file.seek(0)
    return result_file
