from pydantic import BaseModel

class SalaryRequest(BaseModel):
    gross_salary: float
    number_of_dependents: int

class SalaryOutput(BaseModel):
    gross_salary: float
    net_salary: float
    insurance_amount: float
    personal_income_tax: float

class ExcelUploadResponse(BaseModel):
    message: str
    file: bytes
