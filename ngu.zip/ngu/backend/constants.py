class ConstantsSalary:
    BHXH_RATE = 0.08  # Bảo hiểm xã hội
    BHYT_RATE = 0.015  # Bảo hiểm y tế
    BHTN_RATE = 0.01   # Bảo hiểm thất nghiệp
    BASIC_DEDUCTION = 11000000  # Gia cảnh bản thân
    DEPENDENT_DEDUCTION = 4400000  # Gia cảnh người phụ thuộc

class TaxConfig:
    BRACKETS = [
        (5000000, 0.05),
        (10000000, 0.1),
        (18000000, 0.15),
        (32000000, 0.2),
        (52000000, 0.25),
        (80000000, 0.3),
        (float('inf'), 0.35),
    ]
