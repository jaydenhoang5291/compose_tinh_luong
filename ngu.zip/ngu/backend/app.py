from fastapi import FastAPI
from pydantic import BaseModel

# Định nghĩa các mô hình dữ liệu
class SalaryRequest(BaseModel):
    gross_salary: float
    dependents: int

class SalaryResponse(BaseModel):
    gross_salary: float
    net_salary: float
    insurance_amount: float
    personal_income_tax: float

# Các hằng số
BHXH_RATE = 0.08
BHYT_RATE = 0.015
BHTN_RATE = 0.01
BASIC_DEDUCTION = 11000000
DEPENDENT_DEDUCTION = 4400000

# Hàm tính bảo hiểm
def calculate_insurance(gross_salary: float):
    insurance_amount = gross_salary * (BHXH_RATE + BHYT_RATE + BHTN_RATE)
    return insurance_amount

# Hàm tính thu nhập chịu thuế
def calculate_pre_tax_income(gross_salary: float, insurance_amount: float, dependents: int):
    pre_tax_income = gross_salary - insurance_amount - (BASIC_DEDUCTION + dependents * DEPENDENT_DEDUCTION)
    return pre_tax_income

# Hàm tính thuế thu nhập cá nhân
def calculate_tax(pre_tax_income: float):
    if pre_tax_income <= 5000000:
        return pre_tax_income * 0.05
    elif pre_tax_income <= 10000000:
        return (pre_tax_income - 5000000) * 0.1 + 250000
    elif pre_tax_income <= 18000000:
        return (pre_tax_income - 10000000) * 0.15 + 750000
    elif pre_tax_income <= 32000000:
        return (pre_tax_income - 18000000) * 0.2 + 1950000
    elif pre_tax_income <= 52000000:
        return (pre_tax_income - 32000000) * 0.25 + 5150000
    elif pre_tax_income <= 80000000:
        return (pre_tax_income - 52000000) * 0.3 + 10150000
    else:
        return (pre_tax_income - 80000000) * 0.35 + 17150000

# Khởi tạo FastAPI app
app = FastAPI()

@app.post("/calculate_salary", response_model=SalaryResponse)
def calculate_salary(request: SalaryRequest):
    # Tính bảo hiểm
    insurance_amount = calculate_insurance(request.gross_salary)

    # Tính thu nhập trước thuế
    pre_tax_income = calculate_pre_tax_income(request.gross_salary, insurance_amount, request.dependents)

    # Tính thuế thu nhập cá nhân
    personal_income_tax = calculate_tax(pre_tax_income)

    # Tính lương net
    net_salary = request.gross_salary - insurance_amount - personal_income_tax

    # Trả về kết quả
    return SalaryResponse(
        gross_salary=request.gross_salary,
        net_salary=net_salary,
        insurance_amount=insurance_amount,
        personal_income_tax=personal_income_tax
    )
