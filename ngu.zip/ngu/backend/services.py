from fastapi import UploadFile
from .utils import calculate_net_salary, handle_upload_excel

async def handle_convert_gross_to_net(gross_salary: float, number_of_dependents: int):
    """Sử dụng hàm calculate_net_salary để tính toán lương net"""
    return calculate_net_salary(gross_salary, number_of_dependents)

async def handle_upload_excel(file: UploadFile):
    """Xử lý tệp Excel và trả về kết quả"""
    return await handle_upload_excel(file)
